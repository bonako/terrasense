import { initializeApp } from 'firebase/app';

const firebaseConfig = initializeApp ({
    apiKey: "AIzaSyD0_lM4i9Vu51KbQQOUEt00M0mxArOU1cU",
    authDomain: "myapplication-885a4.firebaseapp.com",
    databaseURL: "https://myapplication-885a4.firebaseio.com",
    projectId: "myapplication-885a4",
    storageBucket: "myapplication-885a4.appspot.com",
    messagingSenderId: "315024999053",
    appId: "1:315024999053:web:f33aa706fa9f18533598c4",
    measurementId: "G-PKB1T4ZYBZ"
  });

